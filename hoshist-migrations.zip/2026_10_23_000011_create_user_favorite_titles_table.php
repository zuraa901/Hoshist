<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_favorite_titles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('title_id')->constrained()->cascadeOnDelete();
            $table->unsignedTinyInteger('position')->default(1); // urutan favorit
            $table->unique(['user_id', 'title_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_favorite_titles');
    }
};
